"""
    Ces module permetent de trier une liste dans lordre 
    croissant ou decroissant

"""

from utila import MinToMax
from utila import MaxToMin

__version__ = "0.0.5"