UTILA Library:
==============
Utila ne sert pour l'instant seulement à ranger dans lordre croisssant ou decroissant

Installation:
=============
pip install Utila

Exemple d'usage :
=================
from Utila import MinToMax
MinToMax(a,b) two times the same list


License:
========
WTFPL

Doc:
====
https://github.com/AaIiMm/Utila/wiki/Functions



